<?php
	$nomService="quotasScribe";
	$nomDetailleService="Evaluation des quotas sur le serveur Scribe";
?>