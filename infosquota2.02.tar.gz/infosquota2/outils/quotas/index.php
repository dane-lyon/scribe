<?php
/*---------------------------------------------------------------
		index.php
-----------------------------------------------------------------
	page de base du service
-----------------------------------------------------------------
	auteur : Olivier HACQUARD - Académie de Besançon   
---------------------------------------------------------------*/
include ('./inc/f_session_scribe.inc.php');
//doit être appelé avant initSession qui utilise le ldap pour trouver les infos sur l'utilisateur courant
include ('./inc/f_ldap_scribe.inc.php');
//initialisation de la Session et recup de l'uid, sinon, on retourne à l'authentification du CAS
initSession();

include ('./inc/f_scribe.inc.php');


//------------------- Controler ----------------------

//------------------- Module -------------------------

//on va à la page du service
header("Location: ./quotas.php"); 

//------------------- View -------------------------
?>