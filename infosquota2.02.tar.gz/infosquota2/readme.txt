**************************
Installation automatique :
**************************

1) Sur le serveur Scribe (en root) :
- Lancer les commandes suivantes :
wget dev-eole.ac-dijon.fr/attachments/download/437/instinfosquota2.02
chmod +x instinfosquota2
./instinfosquota2
rm instinfosquota2

2 ) A partir d'un poste Windows :
#Configurer si besoin l'application en �ditant le fichier "infosquota.ini"
- Personnaliser l'application si besoin en �ditant le fichier 
"infosquota.ini"

3) Utilisation :
- Acc�dez en admin � http://scribe/outils/quotas/ 

***********************
Installation manuelle :
***********************

1 ) Sur le serveur Scribe (en root) :

- T�l�charger infosquota2.tar.gz et le d�zipper localement
- Copier le dossier "infosquota" dans le dossier "/home/netlogon/"
- Extraire le fichier "infosquota" du dossier "tache_cron.d" dans le dossier "/etc/cron.d/"
- Extraire le fichier "findfic" du dossier "tache_cron.weekly" dans le dossier "/etc/cron.weekly/"
- Extraire le fichier "apache-outils.conf" du dossier "sites-enabled" dans le dossier "/etc/apache2/sites-enabled/"
- Copier le dossier "outils" dans le r�pertoire /var/www/html/
- Passer les droits :
chmod +x /etc/cron.weekly/findfic

chmod -R 755 /var/www/html/outils/

chown -R root:www-data /var/www/html/outils/quotas/log

chmod -R 2750 /var/www/html/outils/quotas/log
- Red�marrer le cron : /etc/init.d/cron restart
- Lancer une premi�re fois : /etc/cron.weekly/findfic

2 ) A partir d'un poste Windows :

- Configurer si besoin l'application en �ditant le fichier "infosquota.ini"
- Editer le fichier "domainusers.txt" pr�sent dans le dossier "netlogon\scrips\groups\"
- Ajouter les lignes suivantes (SERVEUR-SCRIBE est � remplacer par le nom de votre serveur) :

%%Netuse%%
cmd, \\SERVEUR-SCRIBE\netlogon\infosquota\infosquota.exe

3) Utilisation :

- Acc�dez en admin � http://scribe/outils/quotas/
